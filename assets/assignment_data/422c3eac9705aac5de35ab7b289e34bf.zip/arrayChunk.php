<?php
$givenArray = [3,5,6,1,6,7,1,9,4,3,'a','d','4',3,6,'9','g','k',15];// Given Array
$numberOfChunks = 5; //Number of Chunks or Elements of splited array
$returnArray = splitArray($givenArray,$numberOfChunks); //Function Called
print_r($returnArray);
function splitArray($givenArray,$numberOfChunks){  // Array Chunk Function
$arraySize = count($givenArray); // Size of Given Array
$numbersOfArray = intval($arraySize/$numberOfChunks);// Numbers of Array will be made according to chunks

for($i=0;$i<$numbersOfArray;$i++){ // First Array 
    if($i==0){
        for($j=0 ; $j < $numberOfChunks ; $j++){
            $arrayChunks[$i][] = $givenArray[$j]; 
        }
    }else{ // Other arrays
        $indexEnd = $i+1;  //
        for($j= $numberOfChunks * $i ; $j < $indexEnd * $numberOfChunks; $j++){
            $arrayChunks[$i][] = $givenArray[$j];
        }
    }
}
       if($arraySize%$numberOfChunks!=0){ // Remmaning array of odd condition
       $total = $numberOfChunks * $numbersOfArray;
    for($j=$total; $j < $arraySize ; $j++){
            $arrayChunks[$numbersOfArray][]=$givenArray[$j];
        }
}
return $arrayChunks;
}